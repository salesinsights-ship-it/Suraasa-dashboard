# Suraasa Sales Intelligence Dashboard

Real-time sales dashboard pulling data from your Google Sheet. Pre-configured and ready to deploy.

---

## What's inside

- **Total Sales:** 1,179 (Mar 2025 → May 2026)
- **Revenue:** ₹13.91 Cr (using Col T — Final Payable Amount Converted)
- **Cash-In:** ₹12.23 Cr (Col Q — Amount Received Converted)
- **Collections:** ₹12.56 Cr (Col I — Amount Final Converted)
- **34 active setters** under 4 TLs (Muskan Dua, Priyo Barik, Rishabh Jadon, Training)
- **16 active closers**
- All Show%, PDD:Sale% per setter/closer with date range filtering

---

## Deploy in 3 minutes

### Step 1 — Make your Google Sheet public

1. Open the sheet: https://docs.google.com/spreadsheets/d/1yt1bmwkQ_vF8gPzIsfEUnNygONCXpfAZKSrovm6zlJ8
2. Click **Share** (top right)
3. Under "General access", change "Restricted" to **"Anyone with the link"**
4. Set role to **Viewer**
5. Click **Done**

### Step 2 — Deploy to Netlify

1. Unzip this folder
2. Go to https://app.netlify.com/drop
3. Drag the unzipped `live_v2` folder onto the page
4. Wait 20 seconds for deploy
5. You'll get a URL like `https://random-name.netlify.app`

### Step 3 — Share

Copy the Netlify URL and share with your team via WhatsApp / Slack / email.

---

## Tabs in the dashboard

1. **Overview** — High-level KPIs, funnel, daily trend
2. **Daily Booking vs PDD** — Day-by-day breakdown with Show% and PDD:Sale% trends
3. **Setter Activity** — Per-setter Bookings/CC/PDD/Sales with TL grouping
4. **Setter Show% Table** — Dedicated table for Show% and PDD:Sale% with date range filter
5. **Closer Activity** — Per-closer Booking → CC → PDD → OLS → Sales
6. **Setter Sales** — Revenue/Cash-In/Collection per setter + monthly heatmap
7. **Month vs Month** — Side-by-side comparison of any two months
8. **Weekly Compare** — Week-by-week breakdown within a chosen month
9. **KPI Report** — Executive summary with TL leaderboard
10. **Insights** — Auto-generated insights from the filtered data

---

## How filters work

**Period** and **Date Range** are independent:
- Pick a month from Period → shows that full month
- Pick a date range → shows only those dates (Period resets to "All")

Other filters: **TL · Setter · Closer · Week (1-4)** — all chain together.

Click **Reset All** to clear everything.

---

## Updating the dashboard

The dashboard auto-fetches the latest sheet data on every page load. No re-deploy needed.

- Update the Google Sheet → refresh dashboard → new data appears within ~3 seconds.

---

## Configuration (only if needed)

The dashboard is pre-configured for your sheet. If tab names ever change:

1. Click the ⚙️ icon in the bottom-right corner
2. Update tab names
3. Save & reload

Tabs used:
- `Combined Sales` (cols Date, Setter, Status, Cash-In Q, Closer Final R, Revenue T, TL V)
- `Collections Combined` (cols Date, Amount I, Counsellor M, Setter N)
- `Setter Call & CRM Metric` (per-setter daily activity)
- `Closer CRM Metric` (per-closer daily activity)
- `Call Volume` (daily team call totals)
- `Overall Activity` (daily team funnel)

---

## Files

```
live_v2/
├── index.html         ← Single-file dashboard (Chart.js + PapaParse via CDN)
├── demo_data.json     ← Offline fallback snapshot (~2 MB)
├── netlify.toml       ← Netlify deployment config
└── README.md          ← This file
```

---

## Troubleshooting

**"Could not load data"** → Sheet sharing not set to "Anyone with link". Redo Step 1.

**Numbers don't match the sheet** → The dashboard counts transactions in Combined Sales (excludes refunded/cancelled). Use the Status column to verify.

**Want to reset settings** → Open browser DevTools (F12) → Console → type:
```javascript
localStorage.removeItem('suraasa_dash_v2_config');
location.reload();
```

**Offline mode** → Click ⚙️ → "Use Demo Data" (loads the bundled snapshot).
